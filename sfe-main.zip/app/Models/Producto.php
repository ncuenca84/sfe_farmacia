<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Producto extends Model
{
    protected $fillable = [
        'emisor_id', 'unidad_negocio_id', 'codigo_principal', 'codigo_auxiliar',
        'nombre', 'descripcion', 'precio_unitario',
        'impuesto_iva_id', 'tiene_ice', 'impuesto_ice_id', 'activo',
    ];

    protected function casts(): array
    {
        return [
            'precio_unitario' => 'decimal:6',
            'tiene_ice' => 'boolean',
            'activo' => 'boolean',
        ];
    }

    public function emisor(): BelongsTo
    {
        return $this->belongsTo(Emisor::class);
    }

    public function unidadNegocio(): BelongsTo
    {
        return $this->belongsTo(UnidadNegocio::class);
    }

    public function impuestoIva(): BelongsTo
    {
        return $this->belongsTo(ImpuestoIva::class);
    }

    public function impuestoIce(): BelongsTo
    {
        return $this->belongsTo(ImpuestoIce::class);
    }

    public function inventarios(): HasMany
    {
        return $this->hasMany(Inventario::class);
    }
}
